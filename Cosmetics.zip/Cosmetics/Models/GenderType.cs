﻿namespace Cosmetics.Models
{
    public enum GenderType
    {
        Women,
        Unisex,
        Men
    }
}
